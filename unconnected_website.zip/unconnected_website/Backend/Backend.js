var express = require("express");
var app = express();
var cors = require("cors");

app.use(cors());

var query = "";
let data=[];
const logger = require("morgan");
app.use(logger('dev'));
const fs = require("fs");
const serverSideStorage = "../data/db.json";

fs.readFile(serverSideStorage, function(err, buf) {
    if(err){
        console.log("error: ", err);
    } else {
        data = JSON.parse(buf.toString());
        if(data.length != 0) {
            counter = data[data.length-1];
        }
    }
    console.log("Data read from file.");
});

function saveToServer(data) {
    fs.writeFile(serverSideStorage, JSON.stringify(data), function(err, buf) {
        if(err){
            console.log("error: ", err);
        } else {
            console.log("Data saved successfully");
        }
    }) 
}

var bodyParser = require("body-parser");
app.use('/api/', bodyParser.urlencoded({extended: true}));
app.use('/api/', bodyParser.json());

//var bodyParser = require("body-parser");
app.get('/api/', function (req, res) {
    res.send(data);
    res.end();
})



var Connection = require('tedious').Connection;
var config = {
    server: 'titan.csse.rose-hulman.edu',
    authentication: {
        type: 'default',
        options: {
            userName: 'krzyzehj',
            password: 'Comp$ci23$'
        }
    },
    options: {
        encrypt: true,
        database: 'Rapture',
        trustServerCertificate: true
    }
};
var connection = new Connection(config);


connection.on('connect', function(err) {
    if(err) {
        console.log("Error: ", err);
    } else {
        console.log("Connected");
        query = `EXEC AddDisaster @name = trees, @description = nothing, @range = 3`;
        executable(query);

    }
});

app.post("/api/", function (req, res) {
    let name = req.body.name;
    let description = req.body.description;
    let range = req.body.range;

    let tornadoQuery = `EXEC AddDisaster @name = ${name}, @description = ${description}, @range = ${range}`;
    console.log(tornadoQuery); 
    executable(tornadoQuery);
    res.send("POST Successful");
    res.end();
    console.log("post");
});

connection.connect();
var Request = require('tedious').Request;
var TYPES = require('tedious').TYPES;

function executable(SQLquery) {
    var request = new Request(SQLquery, function(err) {
        if(err) {
            console.log(err);}
        });

        var result = "";
        request.on('row', function(columns) {
            columns.forEach(function(column) {
                if(column.value === null) {
                    console.log('NULL');
                } else {
                    result += column.value + " ";
                }
            });
            console.log(result);
            result = "";
        });

        request.on('done', function(rowCount, more) {
            console.log(rowCount + ' rows returned');
        }); 

        request.on("requestCompleted", function(rowCount, more) {
            connection.close();
        });
        connection.execSql(request);
    }

app.listen(3000);