USE Rapture
GO

DROP TABLE UsefulFor;
DROP TABLE CloseTo;
DROP TABLE HasItem;
DROP TABLE HasSkill;
DROP TABLE Experienced;
DROP TABLE Skill;
DROP TABLE Item;
DROP TABLE Asset;
DROP TABLE Disaster;
DROP TABLE Person;
DROP TABLE Location;










