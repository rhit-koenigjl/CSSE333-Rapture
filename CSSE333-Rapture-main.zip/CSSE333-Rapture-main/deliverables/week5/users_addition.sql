CREATE USER [krzyzehj] FROM LOGIN [krzyzehj]
EXEC sp_addrolemember'db_owner', 'krzyzehj';

GO


CREATE USER [oaldonda] FROM LOGIN [oaldonda]
EXEC sp_addrolemember'db_owner', 'oaldonda';

GO